"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  LayoutDashboard,
  Heart,
  Users,
  FlaskConical,
  Baby,
  DollarSign,
  Trophy,
  Beef,
  ChevronRight,
} from "lucide-react";
import { cn } from "@/lib/utils";

const navItems = [
  {
    href: "/dashboard",
    label: "Dashboard",
    icon: LayoutDashboard,
  },
  {
    href: "/doadoras",
    label: "Doadoras",
    icon: Heart,
  },
  {
    href: "/rebanho",
    label: "Rebanho",
    icon: Beef,
  },
  {
    href: "/aspiracoes",
    label: "Aspirações / OPU",
    icon: FlaskConical,
  },
  {
    href: "/embrioes",
    label: "Embriões",
    icon: Baby,
  },
  {
    href: "/pista",
    label: "Pista / Exposições",
    icon: Trophy,
  },
  {
    href: "/financeiro",
    label: "Financeiro",
    icon: DollarSign,
  },
];

export function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="w-60 min-h-screen bg-brand-900 text-white flex flex-col shrink-0">
      {/* Logo */}
      <div className="px-5 py-6 border-b border-brand-800">
        <div className="flex items-center gap-3">
          <div className="w-9 h-9 rounded-lg bg-brand-600 flex items-center justify-center">
            <span className="text-white font-bold text-sm">SE</span>
          </div>
          <div>
            <p className="font-semibold text-sm leading-tight">SE Agro Elite</p>
            <p className="text-xs text-brand-300 leading-tight">Nelore de Elite</p>
          </div>
        </div>
      </div>

      {/* Navegação */}
      <nav className="flex-1 px-3 py-4 space-y-0.5">
        {navItems.map((item) => {
          const isActive = pathname === item.href || pathname.startsWith(item.href + "/");
          const Icon = item.icon;
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors",
                isActive
                  ? "bg-brand-700 text-white"
                  : "text-brand-200 hover:bg-brand-800 hover:text-white"
              )}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span className="flex-1">{item.label}</span>
              {isActive && <ChevronRight className="w-3 h-3 opacity-60" />}
            </Link>
          );
        })}
      </nav>

      {/* Rodapé */}
      <div className="px-5 py-4 border-t border-brand-800">
        <p className="text-xs text-brand-400">v0.1.0 — 2026</p>
      </div>
    </aside>
  );
}
