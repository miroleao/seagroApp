import { createClient } from "@/lib/supabase/server";
import { formatDate, FARM_ID } from "@/lib/utils";
import type { Animal } from "@/types";

export default async function DoadorasPage() {
  const supabase = await createClient();

  const { data: doadoras } = await supabase
    .from("animals")
    .select("*")
    .eq("farm_id", FARM_ID)
    .eq("tipo", "DOADORA")
    .order("nome", { ascending: true });

  return (
    <div className="p-6 space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Doadoras</h1>
        <p className="text-sm text-gray-500 mt-0.5">{doadoras?.length ?? 0} doadoras cadastradas</p>
      </div>

      <div className="card overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="bg-gray-50 border-b border-gray-100 text-left">
              <th className="px-4 py-3 font-medium text-gray-600">Animal</th>
              <th className="px-4 py-3 font-medium text-gray-600">RGN</th>
              <th className="px-4 py-3 font-medium text-gray-600">Nascimento</th>
              <th className="px-4 py-3 font-medium text-gray-600">Pai</th>
              <th className="px-4 py-3 font-medium text-gray-600">Mae</th>
              <th className="px-4 py-3 font-medium text-gray-600">Localizacao</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50">
            {doadoras?.map((d: Animal) => (
              <tr key={d.id} className="table-row-hover">
                <td className="px-4 py-3 font-medium text-gray-900">{d.nome}</td>
                <td className="px-4 py-3 text-gray-500 font-mono text-xs">{d.rgn ?? "—"}</td>
                <td className="px-4 py-3 text-gray-500">{formatDate(d.nascimento)}</td>
                <td className="px-4 py-3 text-gray-500 truncate max-w-xs">{d.pai_nome ?? "—"}</td>
                <td className="px-4 py-3 text-gray-500 truncate max-w-xs">{d.mae_nome ?? "—"}</td>
                <td className="px-4 py-3 text-gray-500">{d.localizacao ?? "—"}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
