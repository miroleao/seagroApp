import { createClient } from "@/lib/supabase/server";
import { formatDate, formatCurrency, FARM_ID } from "@/lib/utils";
import {
  Baby, FlaskConical, Heart, DollarSign,
  AlertTriangle, CalendarClock, TrendingUp, Beef,
} from "lucide-react";

// ─── Cartão de estatística ────────────────────────────────────────────────────
function StatCard({
  label, value, sub, icon: Icon, color,
}: {
  label: string;
  value: string | number;
  sub?: string;
  icon: React.ElementType;
  color: string;
}) {
  return (
    <div className="card p-5 flex items-start gap-4">
      <div className={`p-3 rounded-xl ${color}`}>
        <Icon className="w-5 h-5 text-white" />
      </div>
      <div className="flex-1 min-w-0">
        <p className="text-sm text-gray-500 truncate">{label}</p>
        <p className="text-2xl font-bold text-gray-900">{value}</p>
        {sub && <p className="text-xs text-gray-400 mt-0.5">{sub}</p>}
      </div>
    </div>
  );
}

// ─── Badge de dias ────────────────────────────────────────────────────────────
function DiasBadge({ dias }: { dias: number }) {
  if (dias < 0)
    return <span className="badge bg-red-100 text-red-700">Atrasado {Math.abs(dias)}d</span>;
  if (dias === 0)
    return <span className="badge bg-orange-100 text-orange-700">Hoje!</span>;
  if (dias <= 7)
    return <span className="badge bg-yellow-100 text-yellow-700">{dias}d</span>;
  if (dias <= 30)
    return <span className="badge bg-blue-100 text-blue-700">{dias}d</span>;
  return <span className="badge bg-gray-100 text-gray-600">{dias}d</span>;
}

export default async function DashboardPage() {
  const supabase = await createClient();

  // ─── Totais ───────────────────────────────────────────────────────────────
  const [
    { count: totalDoadoras },
    { count: totalReceptoras },
    { count: totalEmbrioes },
    { count: totalAnimais },
  ] = await Promise.all([
    supabase.from("animals").select("*", { count: "exact", head: true })
      .eq("farm_id", FARM_ID).eq("tipo", "DOADORA"),
    supabase.from("animals").select("*", { count: "exact", head: true })
      .eq("farm_id", FARM_ID).eq("tipo", "RECEPTORA"),
    supabase.from("embryos").select("*", { count: "exact", head: true })
      .eq("farm_id", FARM_ID).eq("status", "DISPONIVEL"),
    supabase.from("animals").select("*", { count: "exact", head: true })
      .eq("farm_id", FARM_ID).neq("tipo", "DESCARTE"),
  ]);

  // ─── Nascimentos próximos (próximos 90 dias) ──────────────────────────────
  const hoje = new Date().toISOString().split("T")[0];
  const em90 = new Date(Date.now() + 90 * 86400000).toISOString().split("T")[0];

  const { data: nascimentos } = await supabase
    .from("pregnancy_diagnoses")
    .select(`
      id,
      data_previsao_parto,
      resultado,
      transfer:transfers (
        id,
        receptora_brinco,
        sessao_nome,
        receptora:animals ( nome, brinco ),
        embryo:embryos (
          aspiration:aspirations ( doadora_nome, touro_nome )
        )
      )
    `)
    .eq("farm_id", FARM_ID)
    .eq("resultado", "POSITIVO")
    .gte("data_previsao_parto", hoje)
    .lte("data_previsao_parto", em90)
    .order("data_previsao_parto", { ascending: true })
    .limit(10);

  // ─── Parcelas a vencer (próximos 30 dias) ─────────────────────────────────
  const em30 = new Date(Date.now() + 30 * 86400000).toISOString().split("T")[0];

  const { data: parcelas } = await supabase
    .from("installments")
    .select(`
      id, numero, vencimento, valor, status,
      transaction:transactions ( tipo, animal_nome, contraparte,
        auction:auctions ( nome )
      )
    `)
    .eq("farm_id", FARM_ID)
    .eq("status", "PENDENTE")
    .lte("vencimento", em30)
    .order("vencimento", { ascending: true })
    .limit(10);

  // ─── Calcular dias restantes ──────────────────────────────────────────────
  function diasRestantes(data: string) {
    const d = new Date(data + "T12:00:00");
    const h = new Date(); h.setHours(0,0,0,0);
    return Math.round((d.getTime() - h.getTime()) / 86400000);
  }

  return (
    <div className="p-6 space-y-8">
      {/* Cabeçalho */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-sm text-gray-500 mt-1">
          SE Agropecuária Nelore de Elite — {new Date().toLocaleDateString("pt-BR", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
        </p>
      </div>

      {/* Cards de estatísticas */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label="Doadoras ativas"  value={totalDoadoras ?? 0}  icon={Heart}       color="bg-pink-500" />
        <StatCard label="Receptoras"       value={totalReceptoras ?? 0} icon={Beef}        color="bg-amber-500" />
        <StatCard label="Embriões disp."   value={totalEmbrioes ?? 0}   icon={FlaskConical} color="bg-brand-600" />
        <StatCard label="Total de animais" value={totalAnimais ?? 0}    icon={TrendingUp}  color="bg-indigo-500" />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">

        {/* Alertas de Nascimentos */}
        <section className="card">
          <div className="px-5 py-4 border-b border-gray-100 flex items-center gap-2">
            <Baby className="w-4 h-4 text-brand-600" />
            <h2 className="font-semibold text-gray-900">Próximos Nascimentos</h2>
            <span className="badge bg-brand-100 text-brand-700 ml-auto">
              {nascimentos?.length ?? 0} nos próximos 90 dias
            </span>
          </div>

          {!nascimentos?.length ? (
            <div className="px-5 py-8 text-center text-gray-400 text-sm">
              Nenhum nascimento previsto nos próximos 90 dias
            </div>
          ) : (
            <div className="divide-y divide-gray-50">
              {nascimentos.map((dg) => {
                const t = dg.transfer as any;
                const receptora = t?.receptora?.nome || t?.receptora_brinco || "—";
                const doadora   = t?.embryo?.aspiration?.doadora_nome || "—";
                const touro     = t?.embryo?.aspiration?.touro_nome || "—";
                const dias      = diasRestantes(dg.data_previsao_parto!);
                return (
                  <div key={dg.id} className="px-5 py-3 flex items-center gap-3">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 truncate">
                        {receptora}
                      </p>
                      <p className="text-xs text-gray-500 truncate">
                        {doadora} × {touro}
                      </p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-xs text-gray-400">{formatDate(dg.data_previsao_parto)}</p>
                      <DiasBadge dias={dias} />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>

        {/* Parcelas a Vencer */}
        <section className="card">
          <div className="px-5 py-4 border-b border-gray-100 flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-amber-600" />
            <h2 className="font-semibold text-gray-900">Parcelas a Vencer</h2>
            <span className="badge bg-amber-100 text-amber-700 ml-auto">
              próximos 30 dias
            </span>
          </div>

          {!parcelas?.length ? (
            <div className="px-5 py-8 text-center text-gray-400 text-sm">
              Nenhuma parcela nos próximos 30 dias
            </div>
          ) : (
            <div className="divide-y divide-gray-50">
              {parcelas.map((p) => {
                const t = p.transaction as any;
                const leilao = t?.auction?.nome || "—";
                const animal = t?.animal_nome || "—";
                const tipo   = t?.tipo === "COMPRA" ? "🔴 Compra" : "🟢 Venda";
                const dias   = diasRestantes(p.vencimento);
                return (
                  <div key={p.id} className="px-5 py-3 flex items-center gap-3">
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium text-gray-900 truncate">{animal}</p>
                      <p className="text-xs text-gray-500 truncate">{tipo} · {leilao}</p>
                    </div>
                    <div className="text-right shrink-0">
                      <p className="text-sm font-semibold text-gray-900">
                        {formatCurrency(p.valor)}
                      </p>
                      <DiasBadge dias={dias} />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </section>

      </div>

      {/* Aviso de configuração */}
      <div className="card p-4 flex items-start gap-3 border-amber-200 bg-amber-50">
        <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
        <div className="text-sm text-amber-800">
          <strong>Configuração necessária:</strong> Certifique-se de que o arquivo{" "}
          <code className="bg-amber-100 px-1 rounded">.env.local</code> está preenchido com
          a URL e chave do Supabase antes de rodar o projeto.
        </div>
      </div>
    </div>
  );
}
