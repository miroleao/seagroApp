export default function Page() {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold text-gray-900 capitalize">Aspiracoes</h1>
      <p className="text-gray-500 mt-1 text-sm">Em construção…</p>
    </div>
  );
}
